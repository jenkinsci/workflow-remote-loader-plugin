package some.pack

public class Hello {
  public static String getPhrase() {
    return "Hello groovy World!"
  }

  public static void say() {
    echo getPhrase()
  }
}
