package some.pack

public static String getPhrase() {
    return "Hello groovy World!"
}

public static void say() {
    echo getPhrase()
}

