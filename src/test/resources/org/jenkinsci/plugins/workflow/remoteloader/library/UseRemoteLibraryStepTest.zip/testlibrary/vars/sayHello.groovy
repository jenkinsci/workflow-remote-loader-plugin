import some.pack.Hello

void call() {
  Hello.say()
}

return this
