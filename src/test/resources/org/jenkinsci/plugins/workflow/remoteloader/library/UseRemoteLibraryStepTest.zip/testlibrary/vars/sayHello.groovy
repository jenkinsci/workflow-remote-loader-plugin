import some.pack.Hello

void call() {
  echo Hello.say()
}

return this
